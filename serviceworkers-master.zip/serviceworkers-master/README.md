# Service Workers

In this repository you will find sample code of service workers implementing the following features:

- Offline page (location: **/ServiceWorker1** folder)
- Offline copy of pages (location: **/ServiceWorker2** folder)
- Combination of offline page + offline copy of pages (location: **/ServiceWorker3** folder)
